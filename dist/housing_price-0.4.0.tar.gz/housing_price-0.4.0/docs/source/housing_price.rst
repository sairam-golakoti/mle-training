housing\_price package
======================

Submodules
----------

housing\_price.ingest\_data module
----------------------------------

.. automodule:: housing_price.ingest_data
   :members:
   :undoc-members:
   :show-inheritance:

housing\_price.score module
---------------------------

.. automodule:: housing_price.score
   :members:
   :undoc-members:
   :show-inheritance:

housing\_price.train module
---------------------------

.. automodule:: housing_price.train
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: housing_price
   :members:
   :undoc-members:
   :show-inheritance:
